const appSettings = {
    databaseURL: "https://calculator-469c6-default-rtdb.asia-southeast1.firebasedatabase.app/"
}

function add(value){
document.getElementById('display').value +=value
}

function cleardisplay(){
    document.getElementById('display').value="0";
}

function total(){
    const expression=document.getElementById('display').value;


const result=eval(expression)
document.getElementById('display').value="total = "+result;

}
document.getElementById('display').value="";
    
